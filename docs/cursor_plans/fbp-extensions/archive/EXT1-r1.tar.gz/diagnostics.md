# Diagnostic contract — proposed EXT1-r1

Owners S21–S24. Dependency: [shared contract](shared-contract.md). Existing EX1 ring/capture remains compatible; inspection snapshots remain payload/history-free. This is a separate diagnostic stream.

## Public proposal

```ts
type DiagnosticEvent = Readonly<{
  version: 1; sourceId: string; runId: string; sequence: number;
  kind: 'received' | 'sent' | 'operation-started' | 'operation-finished'
      | 'operation-error' | 'run-terminal' | 'capture-gap';
  nodeId?: string; port?: string; jobId?: string; packetId?: string;
  parents?: readonly string[]; operationId?: string; attempt?: number;
  code?: string; captured?: CapturedJson;
}>;
type CaptureRule = Readonly<{
  nodeId: string; ports?: readonly string[]; jobIds?: readonly string[];
  inputs: boolean; outputs: boolean;
}>;
// proposed host adapter, not an existing Runtime API
openDiagnostics({ runId, rules, expiresAt, limits }): DiagnosticSession;
// session exposes a bounded snapshot/subscription, update(rules), dispose()
```

`CapturedJson` is `{state:'captured',value:JsonValue,bytes:number}` or `{state:'truncated',preview:string,bytes:number}`. When off/denied/not-yet-enabled, no captured value is present; UI distinguishes these reasons through session policy, not fabricated empty payloads. Unsupported future representations use `{state:'unavailable',representationId:string}` after a separately registered safe codec contract exists. No `JSON.stringify` of arbitrary custom objects on the hot path.

S21 freezes an exact field-by-kind table: received/sent require packet/job/node/port; operation kinds require node/operation/attempt and include packet/job when causally attributable; run-terminal has run status/code, never guessed packet attribution. A composite task may have more than one parent; retain immediate lineage.

Each session snapshot also carries trusted run context: graph identity/hash when available, runtime/component versions, active capture policy and policy epoch. Before S32 content identities exist, label the existing graph/run identity as such; do not invent an immutable release. S32+ attaches the pinned semantic revision to this same context. This lets an event explain which code/graph produced it without repeating secret-bearing configuration.

## Baseline and capture policy

Safe structured errors are on for the new diagnostic surface, even with payload capture off; no raw exception message, stack, service URL/token or input is emitted by default. Stable error categories and sanitized code/path preserve useful attribution. Host-supplied application error-detail mapping, if ever added, needs its own reviewed privacy contract; this plan does not emit arbitrary error objects.

Host limits and deny rules dominate all UI requests. Missing rule means metadata only. Match rule by exact node and optional port/job; matching input/output toggles are independent. Invalid/unknown selectors refuse the update atomically. Authorization is an application host responsibility; a catalog cannot enable logging.

Defaults retain EX1 event128/max1024 and payload2048-byte limits. New diagnostic sink defaults: queue128 events, total256KiB, one in-flight batch; host may lower them. Session max15 minutes, max32 rules, max256 job selectors, payload cap2048 UTF-8 bytes. Proposed ceilings, not shipped configuration. Capture is prospective only; enabling never replays effects or claims to reconstruct prior uncaptured data.

Session ID/epoch changes invalidate callbacks and old client updates. Changing capture does not restart the business run. Subscribe reads a current bounded snapshot then updates after its cursor; gaps are explicit, sequences are never reused. Limits and truncation are independent of the runtime admission ledger and cannot weaken deduplication.

## Delivery and ownership

Record `received` at actual process dequeue and `sent` at accepted validated output delivery, preserving existing EX1 semantics. Do not animate scheduling intent as transfer. Operation events come from the single task boundary so retries retain separate attempts and one logical operation.

S23 sink interface: `write(batch: readonly DiagnosticEvent[]): Promise<void>`, `flush():Promise<void>`, `dispose():Promise<void>`. Business path only enqueues into a bounded observer queue; never awaits sink I/O. Drop newest overflow record, increment exact event/byte drop counters and surface a gap summary out-of-band in the session snapshot. Sink failure also increments sink error counter, drops that batch, disables the sink until explicit replacement, and never causes a node retry. Flush only promises delivery of retained queued records; finite host timeout yields an explicit incomplete flush result.

Session disposal is idempotent; unsubscribe/dispose/expiry release owned timers/listeners and cancel queued delivery. An already-running third-party sink write may not be cancellable: adapter receives an abort signal and shutdown receipt reports unresolved adapter I/O honestly. No unbounded promises remain hidden.

## UI and explainability

A node dialog shows purpose, contracts/config summary, selected run/job/attempt, actual input/output or clear uncaptured/truncated reason, error/wait code and immediate parents. Bounded scrollable stages/timeline remain selectable, not only the final output. Source/run changes reset selection safely, not business state. Downloaded JSONL carries schema/policy/capture-gap metadata; diagnostics are observations, not durable workflow checkpoints.

Tests are owned by X21.1–X24.3 in [the ledger](conditions.md), including error-secret omission, per-node policy precedence, session races, sink rejection and installed browser cleanup.
